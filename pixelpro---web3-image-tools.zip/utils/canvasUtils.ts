import { Area } from 'react-easy-crop';
import { ImageFormat, WatermarkSettings } from '../types';

export const createImage = (url: string): Promise<HTMLImageElement> =>
  new Promise((resolve, reject) => {
    const image = new Image();
    image.addEventListener('load', () => resolve(image));
    image.addEventListener('error', (error) => reject(error));
    image.setAttribute('crossOrigin', 'anonymous');
    image.src = url;
  });

export function getRadianAngle(degreeValue: number) {
  return (degreeValue * Math.PI) / 180;
}

/**
 * Returns the new bounding area of a rotated rectangle.
 */
export function rotateSize(width: number, height: number, rotation: number) {
  const rotRad = getRadianAngle(rotation);

  return {
    width:
      Math.abs(Math.cos(rotRad) * width) + Math.abs(Math.sin(rotRad) * height),
    height:
      Math.abs(Math.sin(rotRad) * width) + Math.abs(Math.cos(rotRad) * height),
  };
}

/**
 * Generates a Blob from a canvas
 */
const getCanvasBlob = (canvas: HTMLCanvasElement, type: ImageFormat, quality: number): Promise<Blob> => {
    return new Promise((resolve, reject) => {
        canvas.toBlob(
            (blob) => {
                if (!blob) {
                    reject(new Error('Canvas is empty'));
                    return;
                }
                resolve(blob);
            },
            type,
            quality / 100 // Canvas API takes 0-1
        );
    });
};

// --------------------------------------------------------
// FEATURE: CROP & ROTATE
// --------------------------------------------------------
export async function getCroppedImg(
  imageSrc: string,
  pixelCrop: Area | null,
  rotation = 0,
  flip = { horizontal: false, vertical: false },
  outputFormat: ImageFormat = 'image/jpeg',
  quality = 100
): Promise<{ blob: Blob; url: string }> {
  const image = await createImage(imageSrc);
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');

  if (!ctx) {
    throw new Error('No 2d context');
  }

  const rotRad = getRadianAngle(rotation);

  // calculate bounding box of the rotated image
  const { width: bBoxWidth, height: bBoxHeight } = rotateSize(
    image.width,
    image.height,
    rotation
  );

  // set canvas size to match the bounding box
  canvas.width = bBoxWidth;
  canvas.height = bBoxHeight;

  // translate canvas context to a central location to allow rotating and flipping around the center
  ctx.translate(bBoxWidth / 2, bBoxHeight / 2);
  ctx.rotate(rotRad);
  ctx.scale(flip.horizontal ? -1 : 1, flip.vertical ? -1 : 1);
  ctx.translate(-image.width / 2, -image.height / 2);

  // draw rotated image
  ctx.drawImage(image, 0, 0);

  // croppedAreaPixels values are bounding box relative
  // extract the cropped image using these values
  if (pixelCrop) {
    const data = ctx.getImageData(
        pixelCrop.x,
        pixelCrop.y,
        pixelCrop.width,
        pixelCrop.height
    );

    // set canvas width to final desired crop size - this will clear existing context
    canvas.width = pixelCrop.width;
    canvas.height = pixelCrop.height;

    // paste generated rotate image with correct offsets for x,y crop values.
    ctx.putImageData(data, 0, 0);
  }

  const blob = await getCanvasBlob(canvas, outputFormat, quality);
  return { blob, url: URL.createObjectURL(blob) };
}

// --------------------------------------------------------
// FEATURE: COMPRESS / RESIZE / CONVERT
// --------------------------------------------------------
export async function processResizeAndFormat(
    imageSrc: string,
    targetWidth: number,
    targetHeight: number,
    format: ImageFormat,
    quality: number
): Promise<{ blob: Blob; url: string }> {
    const image = await createImage(imageSrc);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('No 2d context');

    canvas.width = targetWidth;
    canvas.height = targetHeight;

    // High quality scaling
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    ctx.drawImage(image, 0, 0, targetWidth, targetHeight);

    const blob = await getCanvasBlob(canvas, format, quality);
    return { blob, url: URL.createObjectURL(blob) };
}


// --------------------------------------------------------
// FEATURE: WATERMARK
// --------------------------------------------------------
export async function applyWatermark(
    imageSrc: string,
    settings: WatermarkSettings,
    format: ImageFormat
): Promise<{ blob: Blob; url: string }> {
    const image = await createImage(imageSrc);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('No 2d context');

    canvas.width = image.width;
    canvas.height = image.height;

    // Draw original image
    ctx.drawImage(image, 0, 0);

    // Configure text styles
    ctx.font = `${settings.fontSize}px ${settings.fontFamily}`;
    ctx.fillStyle = settings.color;
    ctx.globalAlpha = settings.opacity / 100;
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';

    if (settings.isRepeating) {
        // Rotating repeating pattern
        const diagonal = Math.sqrt(canvas.width ** 2 + canvas.height ** 2);
        
        ctx.save();
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate(getRadianAngle(settings.rotation));
        ctx.translate(-diagonal / 2, -diagonal / 2);

        const spacingX = ctx.measureText(settings.text).width + 100; // Text width + gap
        const spacingY = settings.fontSize + 100; // Text height + gap

        // Create a grid larger than diagonal to cover rotation
        const cols = Math.ceil(diagonal / spacingX) + 2;
        const rows = Math.ceil(diagonal / spacingY) + 2;

        for (let i = 0; i < cols; i++) {
            for (let j = 0; j < rows; j++) {
                ctx.fillText(settings.text, i * spacingX, j * spacingY);
            }
        }
        ctx.restore();

    } else {
        // Single placement
        ctx.save();
        // Since input X/Y are usually % based for better UX, we convert to pixels
        // Assuming X/Y are centered coordinates for the text
        const x = (canvas.width * settings.x) / 100;
        const y = (canvas.height * settings.y) / 100;

        ctx.translate(x, y);
        ctx.rotate(getRadianAngle(settings.rotation));
        ctx.fillText(settings.text, 0, 0);
        ctx.restore();
    }

    // Reset alpha
    ctx.globalAlpha = 1.0;

    const blob = await getCanvasBlob(canvas, format, 100);
    return { blob, url: URL.createObjectURL(blob) };
}