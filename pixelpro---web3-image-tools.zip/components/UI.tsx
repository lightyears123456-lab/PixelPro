import React, { useRef, useState } from 'react';
import { Loader2 } from 'lucide-react';

// --- Card with Spotlight & Flowing Border ---
export const Card: React.FC<{ 
    children: React.ReactNode; 
    className?: string; 
    onClick?: () => void;
    style?: React.CSSProperties;
}> = ({ children, className = '', onClick, style }) => {
  const divRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [opacity, setOpacity] = useState(0);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!divRef.current) return;
    const rect = divRef.current.getBoundingClientRect();
    setPosition({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  const handleMouseEnter = () => setOpacity(1);
  const handleMouseLeave = () => setOpacity(0);

  return (
    <div 
        ref={divRef}
        onClick={onClick}
        onMouseMove={handleMouseMove}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        style={style}
        className={`relative bg-surface/50 backdrop-blur-xl rounded-xl shadow-lg transition-all duration-300 group ${className}`}
    >
      {/* 1. Static Border (dim) */}
      <div className="absolute inset-0 rounded-xl border border-white/10 pointer-events-none" />

      {/* 2. Spotlight Background (Inner Glow) */}
      <div 
        className="pointer-events-none absolute -inset-px transition-opacity duration-300 rounded-xl"
        style={{
            opacity,
            background: `radial-gradient(600px circle at ${position.x}px ${position.y}px, rgba(255,255,255,0.06), transparent 40%)`
        }}
      />

      {/* 3. Spotlight Border (Flowing Line Effect via Mask) */}
      <div
        className="pointer-events-none absolute inset-0 rounded-xl transition-opacity duration-300 z-10"
        style={{
            opacity,
            background: `radial-gradient(400px circle at ${position.x}px ${position.y}px, var(--spotlight-color, #00F0FF), transparent 40%)`,
            maskImage: 'linear-gradient(#fff, #fff), linear-gradient(#fff, #fff)',
            maskClip: 'content-box, border-box',
            maskComposite: 'exclude',
            WebkitMaskComposite: 'xor', // Needed for Chrome/Edge
            padding: '1.5px', // Border width
        }}
      />
      
      {/* Content */}
      <div className="relative z-20 p-6 h-full">
          {children}
      </div>
    </div>
  );
};

// --- Button ---
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger';
  isLoading?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', isLoading, className = '', ...props }) => {
  const baseStyles = "relative px-6 py-2.5 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden group";
  
  const variants = {
    primary: "bg-neon-blue/10 text-neon-blue border border-neon-blue/50 hover:bg-neon-blue hover:text-black hover:shadow-[0_0_20px_#00F0FF]",
    secondary: "bg-white/5 text-white border border-white/10 hover:bg-white/10",
    danger: "bg-red-500/10 text-red-400 border border-red-500/50 hover:bg-red-500 hover:text-white hover:shadow-[0_0_20px_#ef4444]",
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${props.disabled || isLoading ? 'opacity-50 cursor-not-allowed' : ''} ${className}`}
      disabled={props.disabled || isLoading}
      {...props}
    >
      {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
      {children}
    </button>
  );
};

// --- Input/Label ---
export const Label: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
    <label className={`block text-[12px] uppercase tracking-wider text-text-secondary font-mono mb-2 ${className}`}>
        {children}
    </label>
);

export const Input: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => (
    <input 
        className="w-full bg-black/40 border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-neon-blue transition-colors font-mono text-sm"
        {...props}
    />
);

export const Select: React.FC<React.SelectHTMLAttributes<HTMLSelectElement>> = (props) => (
    <select 
        className="w-full bg-black/40 border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-neon-blue transition-colors font-mono text-sm appearance-none cursor-pointer"
        {...props}
    >
        {props.children}
    </select>
);

// --- Slider ---
interface SliderProps extends React.InputHTMLAttributes<HTMLInputElement> {
    label?: string;
    valueDisplay?: string | number;
}

export const Slider: React.FC<SliderProps> = ({ label, valueDisplay, ...props }) => {
    return (
        <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
                {label && <Label className="mb-0">{label}</Label>}
                {valueDisplay !== undefined && <span className="text-neon-blue font-mono text-[12px]">{valueDisplay}</span>}
            </div>
            <input 
                type="range" 
                {...props}
                className={`w-full ${props.className || ''}`}
            />
        </div>
    );
};