import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactCrop, { Area } from 'react-easy-crop';
import { 
    Download, RotateCw, RefreshCcw, 
    ArrowLeft, Image as ImageIcon, 
    Type, Crop as CropIcon, Sliders 
} from 'lucide-react';
import { ToolType, ImageFile, ImageFormat, WatermarkSettings, FONTS } from '../types';
import { Button, Card, Label, Input, Select, Slider } from './UI';
import { getCroppedImg, processResizeAndFormat, applyWatermark } from '../utils/canvasUtils';

interface EditorProps {
    tool: ToolType;
    file: ImageFile;
    onBack: () => void;
}

const ASPECT_RATIOS = [
    { label: '自由', value: undefined },
    { label: '1:1', value: 1 / 1 },
    { label: '4:3', value: 4 / 3 },
    { label: '16:9', value: 16 / 9 },
    { label: '9:16', value: 9 / 16 },
    { label: '5:4', value: 5 / 4 },
];

export const Editor: React.FC<EditorProps> = ({ tool, file, onBack }) => {
    // --- Global State ---
    const [processedUrl, setProcessedUrl] = useState<string>(file.previewUrl);
    const [processedSize, setProcessedSize] = useState<number>(file.size);
    const [isProcessing, setIsProcessing] = useState(false);
    const [outputFormat, setOutputFormat] = useState<ImageFormat>(file.type as ImageFormat);
    
    // --- Compress State ---
    const [width, setWidth] = useState(file.width);
    const [height, setHeight] = useState(file.height);
    const [lockRatio, setLockRatio] = useState(true);
    const [quality, setQuality] = useState(80);

    // --- Crop State ---
    const [crop, setCrop] = useState({ x: 0, y: 0 });
    const [zoom, setZoom] = useState(1);
    const [rotation, setRotation] = useState(0);
    const [aspect, setAspect] = useState<number | undefined>(undefined);
    const [croppedAreaPixels, setCroppedAreaPixels] = useState<Area | null>(null);

    // --- Watermark State ---
    const [wmSettings, setWmSettings] = useState<WatermarkSettings>({
        text: 'PixelPro',
        color: '#ffffff',
        fontSize: 48,
        opacity: 50,
        rotation: 0,
        isRepeating: false,
        x: 50,
        y: 50,
        fontFamily: 'Inter'
    });

    const aspectRatioRef = useRef(file.width / file.height);

    // --- Effects ---
    
    // Auto-process for real-time feedback (debounced ideally, but direct for responsiveness)
    useEffect(() => {
        if (tool === ToolType.COMPRESS || tool === ToolType.CONVERT) {
            const timer = setTimeout(() => {
                handleProcess();
            }, 300);
            return () => clearTimeout(timer);
        }
        // For watermark, we update canvas on change
        if (tool === ToolType.WATERMARK) {
             const timer = setTimeout(() => {
                handleProcess();
            }, 100);
            return () => clearTimeout(timer);
        }
    }, [width, height, quality, outputFormat, wmSettings, tool]);


    // --- Handlers ---

    const handleResizeChange = (dim: 'w' | 'h', val: string) => {
        const num = parseInt(val) || 0;
        if (dim === 'w') {
            setWidth(num);
            if (lockRatio) setHeight(Math.round(num / aspectRatioRef.current));
        } else {
            setHeight(num);
            if (lockRatio) setWidth(Math.round(num * aspectRatioRef.current));
        }
    };

    const handleProcess = async () => {
        if (!file) return;
        setIsProcessing(true);
        try {
            let result: { blob: Blob; url: string } | null = null;

            if (tool === ToolType.COMPRESS || tool === ToolType.CONVERT) {
                 result = await processResizeAndFormat(
                    file.previewUrl,
                    width,
                    height,
                    outputFormat,
                    quality
                );
            } else if (tool === ToolType.WATERMARK) {
                result = await applyWatermark(
                    file.previewUrl,
                    wmSettings,
                    outputFormat
                );
            }

            if (result) {
                setProcessedUrl(result.url);
                setProcessedSize(result.blob.size);
            }
        } catch (error) {
            console.error("Processing failed", error);
        } finally {
            setIsProcessing(false);
        }
    };

    const handleCropComplete = useCallback((croppedArea: Area, croppedAreaPixels: Area) => {
        setCroppedAreaPixels(croppedAreaPixels);
    }, []);

    // Note: 'Apply Crop' button logic has been merged into downloadImage to simplify interactions.

    const downloadImage = async () => {
        let urlToDownload = processedUrl;

        // If CROP, generate on the fly before download
        if (tool === ToolType.CROP && croppedAreaPixels) {
            setIsProcessing(true);
            try {
                const result = await getCroppedImg(
                    file.previewUrl,
                    croppedAreaPixels,
                    rotation,
                    { horizontal: false, vertical: false },
                    outputFormat
                );
                urlToDownload = result.url;
            } catch (e) {
                console.error(e);
                setIsProcessing(false);
                return;
            } finally {
                setIsProcessing(false);
            }
        }

        const link = document.createElement('a');
        link.href = urlToDownload;
        
        // Naming logic
        const ext = outputFormat.split('/')[1];
        const suffix = tool === ToolType.COMPRESS ? '_compressed' : 
                       tool === ToolType.CROP ? '_cropped' :
                       tool === ToolType.CONVERT ? `_converted` : '_watermarked';
                       
        const originalName = file.name.substring(0, file.name.lastIndexOf('.'));
        link.download = `${originalName}${suffix}.${ext}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    // --- Render Helpers ---

    const renderSizeComparison = () => (
        <div className="p-4 rounded-lg bg-black/20 border border-white/10 space-y-3">
            <div className="flex justify-between items-center text-[12px] text-text-secondary uppercase tracking-wider">
                <span>原图体积</span>
                <span className="font-mono">{(file.size / 1024).toFixed(1)} KB</span>
            </div>
            <div className="w-full h-px bg-white/5" />
            <div className="flex justify-between items-center">
                <span className="text-sm font-bold text-neon-blue">处理后</span>
                <span className="font-mono text-sm text-neon-blue font-bold">{(processedSize / 1024).toFixed(1)} KB</span>
            </div>
            {processedSize < file.size && (
                <div className="text-right text-[12px] text-green-400">
                    节省 {((file.size - processedSize) / file.size * 100).toFixed(0)}%
                </div>
            )}
        </div>
    );

    const renderControls = () => {
        switch (tool) {
            case ToolType.COMPRESS:
            case ToolType.CONVERT:
                return (
                    <div className="space-y-6">
                        {tool === ToolType.COMPRESS && (
                            <div className="space-y-4">
                                <Label>图片尺寸 (px)</Label>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <span className="text-[12px] text-text-secondary mb-1 block">宽度</span>
                                        <Input 
                                            type="number" 
                                            value={width} 
                                            onChange={(e) => handleResizeChange('w', e.target.value)} 
                                        />
                                    </div>
                                    <div>
                                        <span className="text-[12px] text-text-secondary mb-1 block">高度</span>
                                        <Input 
                                            type="number" 
                                            value={height} 
                                            onChange={(e) => handleResizeChange('h', e.target.value)} 
                                        />
                                    </div>
                                </div>
                                <label className="flex items-center gap-2 text-sm text-text-secondary cursor-pointer">
                                    <input 
                                        type="checkbox" 
                                        checked={lockRatio} 
                                        onChange={(e) => setLockRatio(e.target.checked)}
                                        className="rounded border-gray-600 bg-black/40 text-neon-blue focus:ring-neon-blue"
                                    />
                                    锁定长宽比
                                </label>
                            </div>
                        )}

                        {tool === ToolType.COMPRESS && (
                            <div className="space-y-4">
                                <Label>压缩质量 ({quality}%)</Label>
                                {outputFormat === 'image/png' && (
                                    <div className="text-[12px] text-yellow-500/90 mb-2 flex items-start gap-1 p-2 bg-yellow-500/10 rounded">
                                        <span>⚠️</span> PNG 为无损格式，调整质量不会改变体积。建议切换为 JPEG 或 WebP。
                                    </div>
                                )}
                                <Slider 
                                    min={1} max={100} 
                                    value={quality} 
                                    onChange={(e) => setQuality(Number(e.target.value))} 
                                    disabled={outputFormat === 'image/png'}
                                    className={outputFormat === 'image/png' ? 'opacity-50 cursor-not-allowed' : ''}
                                />
                                {renderSizeComparison()}
                            </div>
                        )}

                        <div className="space-y-4">
                            <Label>输出格式</Label>
                            <Select 
                                value={outputFormat} 
                                onChange={(e) => setOutputFormat(e.target.value as ImageFormat)}
                            >
                                <option value="image/jpeg">JPEG</option>
                                <option value="image/png">PNG</option>
                                <option value="image/webp">WebP</option>
                            </Select>
                            {/* Size comparison removed for Convert tool */}
                        </div>
                    </div>
                );

            case ToolType.CROP:
                return (
                    <div className="space-y-6">
                         <div className="space-y-4">
                            <Label>裁剪比例</Label>
                            <div className="grid grid-cols-3 gap-2">
                                {ASPECT_RATIOS.map(r => (
                                    <button
                                        key={r.label}
                                        onClick={() => setAspect(r.value)}
                                        className={`text-[12px] py-2 px-1 rounded border transition-all ${aspect === r.value 
                                            ? 'bg-neon-blue/20 border-neon-blue text-neon-blue' 
                                            : 'bg-transparent border-white/10 text-gray-400 hover:border-white/30'}`}
                                    >
                                        {r.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="space-y-4">
                            <Label>旋转角度 ({rotation}°)</Label>
                            <Slider 
                                min={0} max={360} 
                                value={rotation} 
                                onChange={(e) => setRotation(Number(e.target.value))} 
                            />
                        </div>
                        
                         {/* 'Apply Crop' button removed. Merged into Download action. */}
                    </div>
                );

            case ToolType.WATERMARK:
                return (
                    <div className="space-y-5 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
                        {/* 1. Text Content */}
                        <div className="space-y-2">
                            <Label>水印文字</Label>
                            <Input 
                                value={wmSettings.text} 
                                onChange={(e) => setWmSettings({...wmSettings, text: e.target.value})}
                                placeholder="请输入文字..."
                            />
                        </div>

                        {/* 2. Font & Color Settings */}
                        <div className="grid grid-cols-2 gap-4">
                             <div className="space-y-2">
                                <Label>字体</Label>
                                <Select 
                                    value={wmSettings.fontFamily} 
                                    onChange={(e) => setWmSettings({...wmSettings, fontFamily: e.target.value})} 
                                >
                                    {FONTS.map(f => <option key={f} value={f}>{f}</option>)}
                                </Select>
                            </div>
                             <div className="space-y-2">
                                <Label>颜色</Label>
                                <div className="flex gap-2 h-[38px]">
                                    <input 
                                        type="color" 
                                        value={wmSettings.color}
                                        onChange={(e) => setWmSettings({...wmSettings, color: e.target.value})}
                                        className="h-full w-10 bg-transparent border border-white/10 rounded cursor-pointer p-0.5"
                                    />
                                    <Input 
                                        value={wmSettings.color} 
                                        onChange={(e) => setWmSettings({...wmSettings, color: e.target.value})} 
                                        className="flex-1 min-w-0"
                                    />
                                </div>
                            </div>
                        </div>

                        {/* 3. Appearance Settings */}
                        <div className="space-y-4 border-t border-white/5 pt-4">
                            <Label>外观样式</Label>
                            <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                                <Slider 
                                    label="字号"
                                    valueDisplay={`${wmSettings.fontSize}px`}
                                    min={10} max={200} 
                                    value={wmSettings.fontSize} 
                                    onChange={(e) => setWmSettings({...wmSettings, fontSize: Number(e.target.value)})} 
                                />
                                <Slider 
                                    label="透明度"
                                    valueDisplay={`${wmSettings.opacity}%`}
                                    min={0} max={100} 
                                    value={wmSettings.opacity} 
                                    onChange={(e) => setWmSettings({...wmSettings, opacity: Number(e.target.value)})} 
                                />
                            </div>
                             <Slider 
                                label="旋转角度"
                                valueDisplay={`${wmSettings.rotation}°`}
                                min={0} max={360} 
                                value={wmSettings.rotation} 
                                onChange={(e) => setWmSettings({...wmSettings, rotation: Number(e.target.value)})} 
                            />
                        </div>

                        {/* 4. Layout & Position */}
                        <div className="space-y-4 border-t border-white/5 pt-4">
                            <div className="flex items-center justify-between">
                                <Label className="mb-0">布局位置</Label>
                                <div className="flex items-center gap-2">
                                    <input 
                                        type="checkbox" 
                                        id="repeat"
                                        checked={wmSettings.isRepeating}
                                        onChange={(e) => setWmSettings({...wmSettings, isRepeating: e.target.checked})}
                                        className="rounded border-gray-600 bg-black/40 text-neon-blue focus:ring-neon-blue w-4 h-4"
                                    />
                                    <label htmlFor="repeat" className="text-[12px] text-gray-300 cursor-pointer select-none">全图平铺</label>
                                </div>
                            </div>

                            {!wmSettings.isRepeating && (
                                <div className="grid grid-cols-2 gap-4">
                                    <Slider 
                                        label="水平位置 (X)"
                                        valueDisplay={`${wmSettings.x}%`}
                                        min={0} max={100} 
                                        value={wmSettings.x} 
                                        onChange={(e) => setWmSettings({...wmSettings, x: Number(e.target.value)})} 
                                    />
                                    <Slider 
                                        label="垂直位置 (Y)"
                                        valueDisplay={`${wmSettings.y}%`}
                                        min={0} max={100} 
                                        value={wmSettings.y} 
                                        onChange={(e) => setWmSettings({...wmSettings, y: Number(e.target.value)})} 
                                    />
                                </div>
                            )}
                        </div>
                    </div>
                );
        }
    };

    // --- Main Render ---

    return (
        <div className="flex flex-col lg:flex-row h-full gap-6 p-4 md:p-8 max-w-[1600px] mx-auto animate-in fade-in duration-500">
            {/* Left/Top: Editor Area */}
            <div className="flex-1 flex flex-col min-h-[500px]">
                <div className="flex items-center justify-between mb-4">
                    <button 
                        onClick={onBack}
                        className="flex items-center gap-2 text-text-secondary hover:text-neon-blue transition-colors"
                    >
                        <ArrowLeft className="w-4 h-4" /> 返回首页
                    </button>
                    {/* Top Info Removed - Moved to sidebar */}
                </div>

                {/* Canvas Area */}
                <Card className={`flex-1 relative overflow-hidden min-h-[400px] bg-[#0a0a0a] ${tool === ToolType.CROP ? '' : 'flex items-center justify-center'}`}>
                    {tool === ToolType.CROP ? (
                         <div className="absolute inset-0 w-full h-full">
                            <ReactCrop
                                image={file.previewUrl}
                                crop={crop}
                                zoom={zoom}
                                rotation={rotation}
                                aspect={aspect}
                                onCropChange={setCrop}
                                onCropComplete={handleCropComplete}
                                onZoomChange={setZoom}
                                onRotationChange={setRotation}
                            />
                         </div>
                    ) : (
                        <div className="relative max-w-full max-h-full p-4">
                             <img 
                                src={processedUrl} 
                                alt="Preview" 
                                className="max-w-full max-h-[70vh] object-contain shadow-2xl border border-white/5"
                             />
                        </div>
                    )}
                </Card>
            </div>

            {/* Right/Bottom: Controls */}
            <div className="w-full lg:w-[360px] flex flex-col gap-6">
                <Card className="flex-1">
                    <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/10">
                        {tool === ToolType.COMPRESS && <Sliders className="w-5 h-5 text-neon-blue" />}
                        {tool === ToolType.CROP && <CropIcon className="w-5 h-5 text-neon-blue" />}
                        {tool === ToolType.CONVERT && <RefreshCcw className="w-5 h-5 text-neon-blue" />}
                        {tool === ToolType.WATERMARK && <Type className="w-5 h-5 text-neon-blue" />}
                        <h2 className="text-lg font-bold text-white tracking-wide">
                            {tool === ToolType.COMPRESS && "图片压缩"}
                            {tool === ToolType.CROP && "裁剪工具"}
                            {tool === ToolType.CONVERT && "格式转换"}
                            {tool === ToolType.WATERMARK && "添加水印"}
                        </h2>
                    </div>

                    {renderControls()}

                    <div className="mt-8 pt-6 border-t border-white/10 flex gap-4">
                        <Button 
                            variant="secondary" 
                            className="flex-1"
                            onClick={() => {
                                // Reset logic depending on tool
                                setWidth(file.width);
                                setHeight(file.height);
                                setRotation(0);
                                setCrop({ x: 0, y: 0 });
                                setProcessedUrl(file.previewUrl);
                            }}
                        >
                            重置
                        </Button>
                        <Button 
                            variant="primary" 
                            className="flex-1"
                            onClick={downloadImage}
                            isLoading={isProcessing}
                        >
                            <Download className="w-4 h-4" /> 下载图片
                        </Button>
                    </div>
                </Card>
            </div>
        </div>
    );
};